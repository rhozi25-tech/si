    @include('partials/header')

    <div class="konten">
        @yield('isi')
    </div>

    @include('partials/footer')