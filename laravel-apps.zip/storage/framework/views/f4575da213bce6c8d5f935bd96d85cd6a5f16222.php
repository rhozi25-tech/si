

<?php $__env->startSection('isi'); ?>
    <style>
        @media (max-width: 575.98px) {
            .badge-pelatihan {
                padding: 0;
            }


        }
    </style>
    <h2 class="mt-5 mb-5 text-center">Program GSI Academy</h2>

    <div class="event mb-5">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-4">
                        <div class="card shadow-sm program_event mb-3" style="max-height: 700px; transition: all ease 0.4s">
                            <img src="<?php echo e($post['gambar']); ?>" width="100" height="150" class="card-img-top" alt="...">
                            <div class="card-body">
                                <p style="font-size: 14pt;" class="card-title"><a
                                        style="-webkit-line-clamp: 2; display: -webkit-box; -webkit-box-orient: vertical; overflow: hidden;"
                                        href="/program/<?php echo e($post['slug']); ?>"><?php echo e($post['title']); ?></a></p>
                                <hr>
                                <div class="d-flex bd-highlight mb-3">
                                    <div class="mr-auto bd-highlight font-weight-bold">Mulai Rp. 10.000</div>
                                    <div
                                        class="bd-highlight font-weight-bold badge badge-primary ml-1  pt-1 badge-pelatihan">
                                        Pelatihan</div>
                                    <div
                                        class="bd-highlight font-weight-bold badge badge-success ml-1 pt-1 badge-pelatihan">
                                        Buku</div>
                                    <div
                                        class="bd-highlight font-weight-bold badge badge-warning ml-1 pt-1 badge-pelatihan">
                                        Video</div>
                                    <div class="bd-highlight font-weight-bold badge badge-danger ml-1 pt-1 badge-pelatihan">
                                        Slide</div>
                                </div>
                                <hr>
                                
                                <a href="/program/<?php echo e($post['slug']); ?>" class="btn btn-outline-primary d-block btn-sm">Lihat
                                    Detail</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Barru\OneDrive\xampp2\htdocs\laravel-apps\resources\views/program.blade.php ENDPATH**/ ?>