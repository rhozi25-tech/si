    <?php echo $__env->make('partials/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="konten">
        <?php echo $__env->yieldContent('isi'); ?>
    </div>

    <?php echo $__env->make('partials/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Barru\OneDrive\xampp2\htdocs\laravel-apps\resources\views////layouts/main.blade.php ENDPATH**/ ?>